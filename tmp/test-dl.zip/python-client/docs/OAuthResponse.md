# OAuthResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_token** | **str** | OAuth access token | [optional] 
**token_type** | **str** | OAuth token type | [optional] 
**expires_in** | **str** | OAuth expity time | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


