# GetSubscriptionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active_days** | **str** | Number of active days | [optional] 
**notify_url** | **str** | Notify url configured | [optional] 
**destination_address** | **str** | The mobile phone number that was allocated | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


